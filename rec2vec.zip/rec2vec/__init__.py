__author__='First Last'
__email__='you_name@ncsu.edu'
__version__='0.0.1'
